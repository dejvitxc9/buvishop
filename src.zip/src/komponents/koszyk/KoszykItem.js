import "./KoszykItem.css";
import { useState, useEffect } from "react";

function KoszykItem(props) {
  let info = props.infoButa;

  let id = info.id;
  let brand = info.brand;
  let model = info.model;
  let size = info.size;
  let material = info.material;
  let price = info.price;

  let wybranyRozmiar = info.rozmiar;
  let wybranaIlosc = info.ilosc;
  let x;

  const kompaktoweDanePrzedmiotu = {
    id: id,
    rozmiar: wybranyRozmiar,
    ilosc: wybranaIlosc
  };

  let imgsrc = "/images/img (" + id + ").png";
  let idinputa = "iloscZamowienia" + id;

  const [currentPrice, setCurrentPrice] = useState(wybranaIlosc * price);

  function edycja() {
    x = parseFloat(document.getElementById(idinputa).value);
    if (isNaN(x)) {
      console.log("Wartość x musi być liczbą!");
      return;
    }

    let nowa = Math.round(price * x * 100) / 100;

    setCurrentPrice(nowa);
    update();
  }

  function update() {
    const zmiana = {
      index: id,
      nowaIlosc: x,
    };
    props.onZmiana(zmiana);
  }

  function usuwanieProduktu() {
    props.onUsun(kompaktoweDanePrzedmiotu);
  }

  return (
    <div className="item" key={id.toString()}>
      <img src={imgsrc} alt={brand}></img>
      <div className="podzialka-m">
        <h1>{model}</h1>
        <h3>{brand}</h3>
      </div>
      <div className="podzialka-l">
        <h4>Wybrany rozmiar: {wybranyRozmiar}</h4>
        <h4>Materiał: {material}</h4>
      </div>
      <div className="podzialka-l">
        <h3>
          Ilość:
          <div className="iloscZamowienia-container">
            <input
              type="number"
              onChange={edycja}
              className="form-control"
              id={idinputa}
              defaultValue={wybranaIlosc}
              min={1}
              max={props.maxButow}
            ></input>
          </div>
          <img
            className="usuwacz"
            src="/images/delete.png"
            alt="Usuń produkt"
            onClick={usuwanieProduktu}
          />
        </h3>
        <h3 className="price">{currentPrice}</h3>
        <br></br>
        <p className="price">cena za sztuke: {price}</p>
      </div>
    </div>
  );
}

export default KoszykItem;
