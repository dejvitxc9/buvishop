import { useState } from "react";
import "./Koszyk.css";
import KoszykItem from "./KoszykItem";

function Koszyk(props) {
  const bazaButow = props.buty;
  const user = props.user;
  let koszykStartowy = user.koszykZakupow;

  const [koszyk, setKoszyk] = useState(koszykStartowy);

  let listaZakupow;
  if (koszyk.length === 0) {
    listaZakupow = <p>Brak produktów w koszyku.</p>;
  } else {
    listaZakupow = koszyk.map(([id, rozmiar, ilosc]) => (
      <KoszykItem
        infoButa={{ ...bazaButow[id], rozmiar, ilosc }}
        onZmiana={aktualicajaPodsumowania}
        key={id}
        maxButow={bazaButow[id].quantity}
        onUsun={props.usuniecieProduktu}
      />
    ));
  }

  function startowykoszyktylko() {
    let koszt = 0;

    for (let i = 0; i < koszyk.length; i++) {
      let butX = bazaButow.find((b) => b.id === koszyk[i][0]); // znajdz produkt z bazy danych po id
      if (butX) {
        koszt += koszyk[i][2] * butX.price; // dodaj koszt produktu do kosztu końcowego
        // console.log(koszt);
      }
    }
    return koszt;
  }

  const [cenyDoPodsumowania, setCenyDoPodsumowania] =
    useState(startowykoszyktylko);

  function aktualicajaPodsumowania(zmiana) {
    const nowyKoszyk = koszyk.map((kItem) =>
      kItem[0] === zmiana.index ? [kItem[0], kItem[1], zmiana.nowaIlosc] : kItem
    );

    setKoszyk(nowyKoszyk);

    let koszt = 0;

    for (let i = 0; i < nowyKoszyk.length; i++) {
      let butX = bazaButow.find((b) => b.id === nowyKoszyk[i][0]);
      if (butX) {
        koszt += nowyKoszyk[i][2] * butX.price;
      }
    }
    setCenyDoPodsumowania(Math.round(koszt * 100) / 100);
  }

  const [cenaDostawy, setCenaDostawy] = useState(9.9);
  function changecenaDostawy() {
    let x = document.getElementById("dostawa").value;
    setCenaDostawy(x);
  }

  return (
    <>
      <div className="koszyk-container">{listaZakupow}</div>
      <div className="podsumowanie-container">
        <h1> Podsumowanie:</h1>
        <h3>Wartość produktów: {Math.round(cenyDoPodsumowania * 100) / 100}</h3>
        <h5>Dostawa: {Math.round(cenaDostawy * 100) / 100} PLN</h5>
        <select
          id="dostawa"
          name="dostawa"
          className="form-select"
          onChange={changecenaDostawy}
        >
          <option defaultChecked value={9.9}>
            InPost Paczkomat - 9.90 PLN
          </option>
          <option value={15.9}>InPost Wysyłka - 15.90 PLN</option>
          <option value={4.9}>Poczta Polska - 4.90 PLN</option>
          <option value={9.99}>ŻabPost - 9.99 PLN</option>
          <option value={12.9}>Orlen Paczka - 12.90 PLN</option>
        </select>
        <br />
        <h3>
          Razem z dostawą:{" "}
          {Math.round(
            (Number(cenyDoPodsumowania) + Number(cenaDostawy)) * 100
          ) / 100}{" "}
          PLN
        </h3>
        <p>
          VAT-23%:{" "}
          {Math.round((Number(cenyDoPodsumowania) + Number(cenaDostawy)) * 23) /
            100}{" "}
          PLN
        </p>

        <hr></hr>
        <button
          className="btn-lg btn-success"
          onClick={() => {
            alert("Ten guzik będzie przekierowywał do strony z płatnościami");
          }}
        >
          Przejdź do płatności
        </button>
        <button
          className="btn-lg btn-warning"
          onClick={() => {
            alert(
              "Ten guzik będzie przekierowywał do strony, która pomoże rozdzieleniu zakupu na raty"
            );
          }}
        >
          Rozłóż na raty
        </button>
      </div>
    </>
  );
}

export default Koszyk;
