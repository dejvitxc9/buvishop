import "./Oferta.css";
import But from "./But";

function Oferta(props) {
  const obuwie = props.oferta;

  const ofertaObuwia = obuwie.map((ofertaButa) => {
    return (
      <But
        id={ofertaButa.id}
        brand={ofertaButa.brand}
        model={ofertaButa.model}
        size={ofertaButa.size}
        material={ofertaButa.material}
        price={ofertaButa.price}
        onAddSecButDoKoszyka={props.onAddButDoKoszyka}
      />
    );
  });

  return <div className="ofertaobuwia">{ofertaObuwia}</div>;
}
export default Oferta;
