import "./But.css";
import ButGuzikAdd from "./ButGuzikAdd";

function But(props) {
  let id = props.id;
  let brand = props.brand;
  let model = props.model;
  let sizes = props.size;
  let material = props.material;
  let price = props.price;
  //   let nxyz = 1;

  const listaRozmiarow = sizes.map((rozm) => {
    if (rozm != null) {
      let zamowienie = [id, rozm, 1];
      return (
        <ButGuzikAdd
          zamowienie={zamowienie}
          onAddTreButDoKoszyka={props.onAddSecButDoKoszyka}
        />
      );
    }
  });

  let imgsrc = "/images/img (" + id + ").png";
  return (
    <div className="ofertaButa" key={id.toString()}>
      <h1>{model} </h1>
      <h5 className="modeltext">{brand}</h5>
      <h4>Materiał: {material}</h4>
      <h5 className="rozmiar-holder">Rozmiar: {listaRozmiarow}</h5>

      <img src={imgsrc} alt={brand}></img>

      <p className="price">{price}</p>
    </div>
  );
}

export default But;
